#!/usr/bin/env python3
"""Frozen #462 physical populations. Standard library; no backend execution."""
from decimal import Decimal as D, getcontext
from itertools import product
from pathlib import Path
import hashlib
import json
import sys

getcontext().prec = 50
ROOT = Path(__file__).resolve().parent
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT
OUT.mkdir(parents=True, exist_ok=True)
DAY = D(1) / 365
EPS = D('0.000001')
FAMILIES = [
    ('D0', '0', D(2), DAY*7, '.70', '1.30', 80, 120, '.05', '.50', '.01', '.10', []),
]

def encode(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False)

def number(x):
    return float(x)

def radical_inverse(n, base):
    out, place = D(0), D(1)
    while n:
        n, digit = divmod(n, base)
        place /= base
        out += digit * place
    return out

def cash(ds):
    return [{'calendar_time': number(t), 'amount': number(a)} for t,a in ds]

ledgers = {k: [] for k in ('required-pricing', 'boundary-admission', 'reference-density', 'exploratory')}
builds = []
for fid,q,T,tlo,mlo,mhi,klo,khi,vlo,vhi,rlo,rhi,divs in FAMILIES:
    q,mlo,mhi,klo,khi,vlo,vhi,rlo,rhi = map(D,(q,mlo,mhi,klo,khi,vlo,vhi,rlo,rhi))
    for kind in ('CALL','PUT'):
        build_id = fid+'-'+kind
        builds.append(dict(id=build_id, option_type=kind, spot=100, dividend_yield=number(q),
            anchor_maturity=number(T), anchored_dividends=cash(divs),
            requested_bounds={name:[number(a),number(b)] for name,a,b in (
                ('moneyness',mlo,mhi),('strike',klo,khi),('maturity',tlo,T),
                ('volatility',vlo,vhi),('rate',rlo,rhi))},
            reference_selection='automatic', backends=['BSpline','Chebyshev','DimensionlessBSpline','DimensionlessChebyshev']))
        rows = {}
        def add(K,m,t,v,r,source):
            # Binary64 public numerical inputs are the canonical deduplication key.
            base = dict(build_id=build_id, option_type=kind, spot=number(m*K),
                        strike=number(K), maturity=number(t), volatility=number(v),
                        rate=number(r), dividend_yield=number(q))
            key = encode(base)
            if key in rows:
                rows[key]['sources'].add(source)
                return
            elapsed = T-t
            rolled = [(d-elapsed,a) for d,a in divs if d-elapsed > 0]
            events = []
            for i,(d,a) in enumerate(divs):
                distance = t-(T-d)
                # Decimal roundoff near zero is below any encoded binary64
                # calendar precision; recognize the declared exact event.
                if abs(distance) < D('1e-45'):
                    distance=D(0)
                    rolled=[(dd-elapsed,aa) for j,(dd,aa) in enumerate(divs)
                            if j != i and dd-elapsed > D('1e-45')]
                if abs(distance) <= EPS+D('1e-45'):
                    events.append(dict(event_index=i, offset_in_tau=number(distance),
                        calendar_side='post' if distance <= 0 else 'pre'))
            rows[key] = dict(base, elapsed_since_anchor=number(elapsed),
                            rolled_dividends=cash(rolled), events=events, sources={source})
        # A: five-dimensional corners.
        for K,m,t,v,r in product((klo,khi),(mlo,mhi),(tlo,T),(vlo,vhi),(rlo,rhi)):
            add(K,m,t,v,r,'A-corner')
        # B: deterministic interior points; Decimal exp/ln avoids libm variation.
        for n in range(1,129):
            u=[radical_inverse(n,b) for b in (2,3,5,7,11)]
            K=klo+u[0]*(khi-klo)
            m=(mlo.ln()+u[1]*(mhi.ln()-mlo.ln())).exp()
            add(K,m,tlo+u[2]*(T-tlo),vlo+u[3]*(vhi-vlo),rlo+u[4]*(rhi-rlo),'B-interior')
        # C: model-semantic strata, unchanged by backend fit outcomes.
        for m,v,r,t in product((mlo,D('.98'),D(1),D('1.02'),mhi),
                              map(D,('.05','.10','.20','.30','.50')),
                              map(D,('-.05','0','.05','.10')),
                              (DAY,DAY*7,DAY*30,D('.25'),D('.5'),D(1),D(2))):
            if vlo<=v<=vhi and rlo<=r<=rhi and tlo<=t<=T:
                add(D(100),m,t,v,r,'C-semantic')
        # D: independently moving spot and strike plus equal-ratio scales.
        for K,S in product(map(D,('97.5','100','102.5')),map(D,('98','100','102'))):
            add(K,S/K,T/2,D('.20'),D('.05'),'D-moving-spot')
        for m,K in product(map(D,('.97','1.03')),(klo,D(100),khi)):
            add(K,m,T/2,D('.20'),D('.05'),'D-equal-ratio')
        # E: ordinary both-side rows stay mandatory; boundary topology has its
        # own ledger. All coincident A-D rows get the same admission policy.
        for i,(d,amount) in enumerate(divs):
            for offset,K,m,v in product((-DAY,-EPS,D(0),EPS,DAY),
                                       (klo,D(100),khi),(mlo,D(1),mhi),(vlo,D('.20'))):
                add(K,m,T-d+offset,v,D('.05'),f'E-event-{i}')
        for key,row in sorted(rows.items()):
            boundary=bool(row['events'])
            row['sources']=sorted(row['sources'])
            row['id']=build_id+'-'+hashlib.sha256(key.encode()).hexdigest()[:20]
            row['expected_price']='accurate_correct_side_or_explicit_domain_refusal' if boundary else 'accurate_success'
            row['iv_measurability']='oracle_qualification_pending'
            ledgers['boundary-admission' if boundary else 'required-pricing'].append(row)
        # Frozen density queries for the documented fixed reference range.
        if fid=='DD':
            refs=[D(90)+D('2.5')*i for i in range(9)]
            Ks=sorted(refs+[(a+b)/2 for a,b in zip(refs,refs[1:])])
            for K,m,v,d in product(Ks,(mlo,D('.98'),D('1.02'),mhi),(vlo,D('.20')),[x[0] for x in divs]):
                for offset in (-DAY,DAY):
                    t=T-d+offset
                    body=dict(build_id=build_id, option_type=kind, spot=number(m*K),strike=number(K),
                              maturity=number(t),volatility=number(v),rate=.05,dividend_yield=number(q),
                              rolled_dividends=cash([(dd-(T-t),a) for dd,a in divs if dd-(T-t)>0]),
                              explicit_reference_strikes=list(map(number,refs)),
                              is_off_reference=K not in refs,
                              expected_status='pending_frozen_460_independent_density_criterion')
                    body['id']='density-'+hashlib.sha256(encode(body).encode()).hexdigest()[:20]
                    ledgers['reference-density'].append(body)

# Exploratory rows remain in the immutable primary v1 manifest.

files={}
def write(name,content):
    data=content.encode()
    (OUT/name).write_bytes(data)
    files[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
write('build-requests.json',encode(builds)+'\n')
for name,rows in ledgers.items():
    rows.sort(key=lambda r:r['id'])
    assert len({r['id'] for r in rows})==len(rows)
    write(name+'.jsonl',''.join(encode(row)+'\n' for row in rows))
counts={name:len(rows) for name,rows in ledgers.items()}
metadata=dict(version='462-cohort-v1-d0-2026-09-06',authority_packet='a5842a15',
              numeric_format='JSON binary64, Decimal precision 50 generation',
              build_requests=len(builds), backend_build_requests=4*len(builds),
              counts=counts, per_family={name:{fid:sum(r.get('build_id','').startswith(fid+'-') for r in rows)
                                        for fid,*_ in FAMILIES} for name,rows in ledgers.items()},
              targets=dict(price_absolute=.01,iv_absolute=.00002,iv_unit='decimal volatility'),
              reference_qualification='pending; no backend outcomes measured',
              boundary_policy='exact-event and |tau-event_tau|<=1e-6: accurate correct-side result or explicit domain refusal; record every gap and refusal',
              expected_invalid_config_ledger='See proposal; numeric valid-query freeze does not guess future error enum or reference-adequacy thresholds')
write('metadata.json',encode(metadata)+'\n')
files['generate.py']={'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT/'SHA256SUMS').write_text(''.join(f"{x['sha256']}  {name}\n" for name,x in sorted(files.items())))
print(encode(metadata))
