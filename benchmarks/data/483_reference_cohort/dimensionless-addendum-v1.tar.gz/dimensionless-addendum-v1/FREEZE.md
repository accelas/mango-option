# Additive dimensionless coverage frozen before tuning

The original 462-cohort-v1 files and digest remain unchanged. This addendum uses family D0: C0 model/domain/recipes A-D with rate bounds [.01,.10], continuous q=0 and no cash dividends. Both option types are replayed on dimensionless B-spline and Chebyshev plus standard B-spline/Cheb controls. No backend fit outcomes were consulted. The dimensionless model restriction is represented explicitly instead of treating the negative-rate C0 build as eligible.

Targets, convergence/measurability protocol, Greek qualification and complete-denominator rules inherit the primary proposal. Independent references and IV eligibility remain pending. All addendum pricing rows are required. No new exploratory rows are added.

Generate with `python3 generate.py OUTPUT_DIR`; verify SHA256SUMS in the addendum directory. The standard-library generator derives this addition deterministically from the original recipe.
