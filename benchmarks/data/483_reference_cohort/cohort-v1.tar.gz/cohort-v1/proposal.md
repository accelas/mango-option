# #462 cohort proposal v1 — declared before backend tuning

Status: exploration only; no production changes, builds, fit-outcome sampling,
or parameter tuning performed for this proposal. Final tuning/strict acceptance
waits for #459. Authority: approved contract.md and 462-acceptance.md in
`docs/superpowers/specs/2026-09-06-483-agent-handoffs` (a5842a15 packet).
This proposal fixes physical cases from the product contract; it does not
inherit a passing subset of the current benchmark. The numeric manifest is now frozen under /home/kai/work/mango-option/.cache/483-research/462-cohort before any candidate-backend comparison. Boundary-ledger alignment was approved by the parent before tuning.

## 1. Required automatic-build families

Anchor spot is 100; quote units are dollars. Both CALL and PUT are required.
Use the same physical queries for B-spline and Chebyshev, recording backend
eligibility/model restrictions explicitly. Start with automatic numerical grids
and automatic reference selection from the declared domains. Numerical seed
counts, K_ref counts, and proof budgets are not part of the physical cohort.

| ID | Model at anchor | T0 | tau domain | S/K domain | absolute K | sigma | r |
|---|---|---:|---|---|---|---|---|
| C0 | continuous q=0, no cash | 2 | [7/365,2] | [.70,1.30] | [80,120] | [.05,.50] | [-.05,.10] |
| C2 | continuous q=.02, no cash | 2 | [7/365,2] | [.70,1.30] | [80,120] | [.05,.50] | [-.05,.10] |
| CS | continuous q=.02, no cash | 7/365 | [1/365,7/365] | [.90,1.10] | [90,110] | [.05,.50] | [-.05,.10] |
| DD | documented adaptive cash case: q=.01, $1.50 at .25 and .50 | 1 | [1/365,1] | [.92,1.08] | [90,110] | [.10,.30] | [.02,.07] |
| DQ | q=.02, $0.50 at 90/365,180/365,270/365 | 1 | [1/365,1] | [.70,1.30] | [80,120] | [.05,.50] | [-.05,.10] |
| DS | q=0, $1 at 10/365 | 30/365 | [1/365,30/365] | [.90,1.10] | [90,110] | [.05,.30] | [-.05,.07] |

These are 12 physical build requests (six families x two option types), replayed
on each eligible backend. DD retains the documented model/domain; DQ repairs
calendar consistency while retaining the existing small quarterly-cash shape.
CS/DS make short-positive-maturity requirements explicit. Required low-vol and
negative-rate cases follow currently supported model inputs, not fit results.

Factory adapters must represent these domains honestly. For example the
continuous Chebyshev factory currently derives tau_min=min(.01,T0/2) and its
adaptive builder widens narrow sample ranges. Use the published measured
bounds to verify admission; do not silently remap a required query to a nearby
time. If an entry point cannot represent/admit a required case, record an API
or domain limitation. Do not delete the case or treat it as a numerical pass.

The old 144-point sweep remains a named historical comparison, not the
acceptance population. Keep its original positive-rate/15%-30%-vol put numbers
separate; it cannot stand in for these families.

## 2. Exact deterministic physical query recipe

Generate the following union per family and option type, deduplicating exact
physical tuples with a documented canonical representation. Assign immutable
IDs before running a backend. m below denotes S/K, not log-moneyness.

A. All 32 corners of (K,m,tau,sigma,r), taking each family's two endpoints.
   Set S=m*K. This includes low-vol, both tails, longest/shortest lifetime,
   endpoint strikes, negative rates where admitted, and independent scaling.

B. 128 fixed interior points: n=1..128, radical-inverse/Halton coordinates in
   bases (2,3,5,7,11) for (K,log(m),tau,sigma,r), scaled to the stated domain.
   This recipe is independent of backend knots and builder LHS seed. Preserve
   the resulting numeric manifest and digest, not only the generator name.

C. Common semantic rows: K=100, m in {lower, .98, 1, 1.02, upper},
   sigma in {.05,.10,.20,.30,.50} intersect the domain, r in {-.05,0,.05,.10}
   intersect the domain, tau in {1/365,7/365,30/365,.25,.50,1,2} intersect
   the domain. Deduplicate endpoints already present. This intentionally
   retains low-vega short/tail prices even when their IV is unmeasurable.

D. Moving-spot rows: hold K in {97.5,100,102.5} and independently vary
   S in {98,100,102}; sigma=.20, r=.05, tau=T0/2. Every family admits these
   coordinates. Also fix m in {.97,1.03}, vary K across {Klo,100,Khi}, and
   set S=m*K. Cash models must not acquire false scale invariance from the
   fact that these rows share m. These are direct-price comparisons, not
   assertions that different absolute cash-dividend contracts cost the same.

E. Dated-event rows: for each original d_i, use tau_i=T0-d_i and
   tau in {tau_i-1/365,tau_i-1e-6,tau_i,tau_i+1e-6,tau_i+1/365}
   (all these rows fall inside the selected families). Cross K in
   {Klo,100,Khi}, m in {lower,1,upper}, sigma in {sigma_lo,.20}, r=.05.
   The tiny offset is in years (~31.5 seconds), fixed before seeing gaps.
   The +/-1-day rows remain required both-side pricing. Exact-event and +/-1e-6 rows use a separate boundary-admission ledger: accurate correct-side price when served, or explicit domain refusal for unsupported topology, as contract section 2 allows. Exact-event served pricing uses the post-dividend calendar side. No gap snapping. All coincident rows from A-D use this same boundary classification; no row disappears.

Every required-pricing-ledger row must succeed and meet the agreed price
target. Every boundary-admission row must return an accurate correct-side
price or an explicit domain refusal; record all refusals and published gaps. An independently IV-measurable row is required to recover the input
sigma to the agreed IV target. Legitimately unidentifiable rows require the
correct refusal status rather than an arbitrary IV. Unsupported mathematical
Greek instants are classified separately below; this does not exempt prices.
If supported builders cannot achieve these requests, report the limitation;
do not retrospectively relabel failed required rows as exploratory.

## 3. Lifecycle/oracle alignment

Dated surfaces represent the same anchored expiry throughout the run.
At each tau, elapsed=T0-tau and query-relative payment time is
`d_query=d_i-elapsed`. Keep strictly future payments and apply direct-pricing
canonical merge/filter rules. An event exactly at valuation is already paid.
Use the same rolled schedule to generate the oracle market price and invert
it. Never regenerate payments as fractions of the query's remaining tau.

For every dated row verify both supported query forms where applicable:
(1) implicit schedule uses the table's anchored model; (2) explicit *rolled*
schedule matches that model. A deliberately stale/unrolled nonempty schedule
is an expected model-mismatch case, not an accuracy row. Changing tau for
theta finite differences must roll the schedule too.

Public seams: make_price_table -> validate_pricing_params -> price/vega and
supported delta/gamma/theta/rho methods; make_iv_solver -> solve/solve_batch.
Replay a small immutable subset after persistence/loading when the new
metadata/certification path exists. Raw sample inspection can diagnose a
failure but cannot substitute for these end-to-end observations.

## 4. Off-reference density and admission subcohorts

Main required automatic queries are fixed regardless of chosen K_refs. Record
how many are off every returned reference and interpolation node. Never alter
the physical query population after inspecting selected refs.

Reuse #460's independently characterized explicit-reference population as a
separate density study: documented [90,92.5,...,110] refs; reference endpoints,
every intervening strike midpoint [91.25,93.75,...,108.75]; variable m and S,
low vol, both event sides, both option types. Query coordinates remain fixed
across each declared candidate density. Exact reference nodes alone do not
measure blended accuracy. No arbitrary explicit count is promised adequate:
expected acceptance/refusal comes from #460's frozen independent criterion,
not whether a particular current fitter happened to return a surface.

Pin typed rejection for nonfinite/nonpositive/duplicate refs, insufficient
strike coverage, queries immediately beyond declared m/K/tau/sigma/r bounds,
and a wrong option type, yield, or rolled payment schedule. Retain each row in
an expected-status denominator. Boundary points themselves remain required
pricing rows. Manual invalid configurations are not silently replaced.

## 5. Oracle protocol (qualify before backend results)

- Exact analytic anchors: no-cash q=0 CALL with r>=0 has European price/Greeks;
  use those cases as independent numerical anchors. Do not apply that equality
  to negative rates or cash/yield cases. Other arbitrage/intrinsic bounds are
  supplementary invariants, not substitute prices.
- General American/cash cases: direct public FDM with the same OptionSpec,
  rolled schedule, and exact sample maturity; converge space, time, and domain
  extent independently. At least three refinement levels and a wider-domain
  cross-check, including stable event placement. A table build, its snapshots,
  or its own holdout score is not this oracle.
- Independent cross-check: QuantLib American PDE on date-aligned cases with
  matched exercise/dividend model and converged mesh. Existing
  quantlib_sweep_regression_test truncates T*365 to integer days: never reuse
  that helper for fractional-day/event-epsilon comparisons. The existing
  quantlib_accuracy discrete-dividend sections contain a TODO and only sanity
  checks, so they do not constitute an independent dividend reference today.
  Implement/verify the actual independent cash-dividend engine before claiming
  that cross-check, or label converged direct-FDM-only evidence honestly.
- Proposed oracle uncertainty allocation: <=10% of each tested error target;
  price <=.001 quote units and IV <=2e-6 decimal vol. For IV, price convergence
  must also resolve the corresponding local vega-scaled IV budget; .001 price
  alone is insufficient. Stable last refinements are empirical evidence,
  not a proven error bound. If estimated reference uncertainty straddles an
  acceptance threshold, require further convergence rather than rounding the
  case into a pass. If convergence is inconclusive, label the row
  oracle-unresolved and block that acceptance claim; never filter it away.
- Generate synthetic market prices at the manifest sigma. Compute measurability
  only from converged oracle TV/K and reference vega, before backend runs.
  Preserve TV/K<1e-4 OR vega below configured floor as IV-filtered. Record the
  exact floor and vega units (quote price per decimal volatility). No filtered
  point contributes zero IV error; price remains required.
- Greeks: use analytic values where valid, otherwise independently converged
  direct-price bump sequences (spot, sigma, rate, rolled calendar time).
  Vary both FDM accuracy and bump size. Theta is calendar-time derivative:
  minus remaining-tau derivative with consistent schedule rolling. Never take
  a central stencil across a dividend jump. At the exact event, record theta
  as one-sided/undefined according to the documented public Greek contract;
  do not compare a jump quotient with smooth theta. Record exercise-boundary
  regularity limits before inspecting a fitted Greek.
- Preserve existing tighter regression tolerances. Existing same-surface
  finite-difference checks (delta .05/gamma .01) and raw-polynomial tests are
  not universal independent fitted-Greek accuracy limits. Set any new Greek
  threshold from oracle convergence/declared Greek accuracy before candidates;
  do not fit a tolerance to the measured backend error. Unsettled Greek
  thresholds are an explicit remaining oracle-qualification task, not license
  to claim monotonicity proves Greek accuracy.

## 6. Separate exploratory stress cohort

Freeze separately: sigma {.01,.02,.80,1.50}; r {-.10,.20}; m {.25,.50,2,4};
very short tau {1e-6,1e-4} and long T0 {5,10}; dividends {$5,$20}, two distinct
payments very close together, and large coverage widths. Build matching
explicit domains; preserve model restrictions, and count refusals as outcomes.
Term-structure inputs are direct-FDM/control cases unless the interpolation
backend explicitly supports them; rate-to-zero-rate approximation is not
full curve fidelity. No unadvertised model promotion is inferred here.

Exploratory refusal is allowed and counted; incorrect returned prices,
nonfinite successful results, or false certification remain defects. These
results cannot replace failed required rows or justify loosening targets.

## 7. Counters and acceptance, fixed before tuning

Build ledger per backend/family: requested; successful; invalid config;
accuracy refusal; certificate witnessed violation; proof-budget unknown;
unmeasurable IV-target refusal; other failure. Failed required build expands
to all planned query rows as build-unavailable: denominator stays intact.

For the valid pricing population N_price, every row ends in exactly one of:
price within target / price outside target / build unavailable / query failed /
nonfinite result / oracle unresolved. Max absolute error gates acceptance;
RMS is secondary and printed with its successful-row denominator.

Separately N_IV_candidate = reference-measurable + TV-filtered + vega-filtered
+ both-filtered + oracle-unresolved, using exclusive categories. For the fixed
reference-measurable set, report IV within/outside target, build unavailable,
query refusal, and nonfinite result. For filtered rows report actual status;
none counts as measured-zero. For expected invalid/model-mismatch rows report
expected-status pass/fail, separate from numerical errors. Greek ledgers are
per-Greek and distinguish oracle unresolved and mathematically unavailable.

Strict default: max price error <=.01 and independently measurable max IV
error <=2e-5 (0.2 absolute-IV bp). Required-cohort violations or unresolved
reference evidence produce nonzero benchmark exit status. A deliberate
price-only build with all IV rows filtered may succeed with IV unmeasured;
the corresponding IV-targeted build must refuse. Best-effort is an explicit
separate invocation and cannot satisfy a strict pass by changing its label.

Only after acceptance: compare query latency for the identical measured rows.
Record build time, peak memory, PDE counts, actual reference density, proof
work, target/achieved errors and all refusal counters together. Manifest IDs,
backend revision/config, oracle revision/convergence history, and resource
limits travel with results. Store large generated data on the normal disk,
not /tmp (tmpfs pressure); this file is intentionally a small proposal.
