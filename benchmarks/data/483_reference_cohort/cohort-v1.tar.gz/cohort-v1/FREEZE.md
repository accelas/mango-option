# #462 physical cohort v1 freeze — 2026-09-06

Approved physical families and recipes are frozen before backend fitting or
parameter tuning. Authority: a5842a15 contract/462 handoffs plus parent approval
of proposal and boundary-admission alignment. No backend outcomes were used.

Artifacts: generate.py (standard-library Python, Decimal precision50),
build-requests.json, four numeric JSONL ledgers, metadata.json and SHA256SUMS.
The generator emits canonical JSON binary64 inputs and stable case IDs.
Run `python3 generate.py OUTPUT_DIRECTORY`; generated manifest bytes/digests
match the frozen versions. `sha256sum -c SHA256SUMS` verifies the source and
primary generated files. proposal.md records the explanatory protocol.

12 physical build requests x two eligible backends = 24 backend build requests.
- Required pricing: 6,994 rows (both +/-1-day event sides mandatory).
- Boundary admission: 690 rows (exact events and +/-1e-6 year).
- Explicit-reference density: 1,088 rows (criterion inherited from #460).
- Exploratory stress: 34 rows, fixed one-factor stress changes.

Boundary admission is declared separately BEFORE tuning under contract §2:
accurate correct-side price when served, or explicit domain refusal when the
boundary/topology is unsupported. Never replace a query with a neighbor's
price. Record all boundary successes/refusals and published gaps. Any A-D row
coinciding with an event/epsilon boundary uses the same classification; no
physical row is dropped. Required both-side +/-1-day prices remain mandatory.

Independent oracle convergence, IV-measurability classification, and new Greek
threshold qualification remain pending. These must be frozen without consulting
candidate-backend fit errors. Expected invalid-configuration tests are described
in proposal.md; future typed enums/reference-adequacy cutoffs are not guessed.
No production acceptance or tuning work proceeds before #459.

Checks completed: SHA256 verification; independent output-directory regeneration
with byte-for-byte comparison; unique IDs; physical domain checks; rolled future
payment validity; exact-event post-side classification; all 7,684 primary rows
partitioned between the required and boundary ledgers. No backend was built.
